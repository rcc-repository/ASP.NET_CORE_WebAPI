export class Produto {
  fornecedorId: string;
  nome: string;
  descricao: string;
  imagemUpload: string;
  imagem: string;
  valor: number;
  ativo: boolean;
  nomeFornecedor: string;
}
